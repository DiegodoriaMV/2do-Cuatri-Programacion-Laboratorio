#include <stdio.h>
#include <stdlib.h>

int main()
{

char sexo[5];
int i;

for (i = 0; 1 < 5; i++)
{
    printf("ingrese el sexo 'm' o 'f' ");
    fflush(stdin);
    scanf("%c",&sexo[]);

    while(sexo != 'm' || sexo != 'f');
    {
        printf("ERROR, ingrese el sexo 'm' o 'f' ");
        fflush(stdin);
        scanf("%c",&sexo);
    }
}

printf("%c",sexo[5]);


/* ------ejercicio 1----
    int numeros [5];
    int i;
    int indice;
    int mayor;
    int flag = 0;


    for(i = 0; i < 5;i++)
    {
        printf("ingrese numero positivos ");
        scanf("%d", &numeros[i]);

        while(numeros[i] <= 0)
        {
            printf("ERROR ,ingrese numero positivos ");
            scanf("%d", &numeros[i]);
        }
    }

    for(i = 0; i< 5; i++)
    {
        if(numeros[i] > mayor || flag == 0)
        {
            mayor = numeros[i];
            flag = 1;
        }
    }
//      donde esta hubicado el mayor y mostrar el indice con un for capas

    printf("El array contiene: ");
    for(i = 0; i< 5; i++)
        {
            printf("%d ",numeros[i]);
        }

    printf("\n El mayor es %d", mayor);
*/
    /* ---array de forma implisita----

    int numeros [10] = {1,2,3,4,5,6,7,8,9,10};
    int i;
    for(i = 0; i < 10;i++)
    {
        printf("%d\n",numeros[i]);
    }
    */
    return 0;
}
