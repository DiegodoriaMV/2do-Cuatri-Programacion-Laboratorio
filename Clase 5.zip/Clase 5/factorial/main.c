#include <stdio.h>
#include <stdlib.h>
//#include ""

int factoriar(int x);
int main()
{

  //  printf("%d",factoriar(5)); aca muestra el numero ingresado como parametro, abajo pido por usuario
    int x;

    printf("Ingrese un numero !\n");
    scanf("%d",&x);

    printf("%d",factoriar(x));
    return 0;
}
int factoriar(int x)
{
    int fact = 1;

    /*--------- FUNCION RECURSIVA-------
    if(x > 1)
    {
        fact = x * factoriar(x-1);
    }
    --------- FUNCION RECURSIVA-------*/

    while (x > 1)
    {
        fact = fact * x;
        x--;
    }

    return fact;
}
/*
    una funcion recursiva es una funcion q se llama a asi misma
    (se apila una sobre la otra hasta q llegue a una q los desbloquea)
*/

